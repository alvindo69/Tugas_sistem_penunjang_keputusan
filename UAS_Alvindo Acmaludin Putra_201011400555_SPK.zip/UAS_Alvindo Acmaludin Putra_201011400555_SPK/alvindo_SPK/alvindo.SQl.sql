INSERT INTO smartphonelenovo (brand,ram,prosesor,storage,baterai,harga,ukuran_layar) VALUES
	 ('Lenovo C11','2 GB','MediaTek Helio G35','32 GB','5.000 mAh','Rp.1.499.000','6.5 inch'),
	 ('Lenovo C15','4 GB','MediaTek Helio G35','64 GB','6.000 mAh','Rp.1.999.000','6.5 inch'),
	 ('Lenovo 8 Pro','8 GB','Qualcomm Snapdragon 720G','128 GB','4.500 mAh','Rp.3.999.000','6.4 inch'),
	 ('Lenovo X7 Pro','8 GB','MediaTek Dimensity 1000+','128 GB','4.500 mAh','Rp.4.999.000','6.55 inch'),
	 ('Lenovo GT Neo','8 GB','MediaTek Dimensity 1200','128 GB','4.500 mAh','Rp.4.999.000','6.43 inch'),
	 ('Lenovo X50 Pro','12 GB','Qualcomm Snapdragon 865','128 GB','4.200 mAh','Rp.7.999.000','6.44 inch'),
	 ('Lenovo Narzo 50A','4 GB','MediaTek Helio G85','64 GB','6.000 mAh','Rp.2.499.000','6.5 inch'),
	 ('Lenovo 9','8 GB','MediaTek Dimensity 810','128 GB','5.000 mAh','Rp.3.999.000','6.5 inch'),
	 ('Lenovo X9 Pro','12 GB','Qualcomm Snapdragon 870','128 GB','4.500 mAh','Rp.5.999.000','6.55 inch'),
	 ('Lenovo GT 2','12 GB','Qualcomm Snapdragon 898','128 GB','5.000 mAh','Rp.5.970.000','6.62 inch');
